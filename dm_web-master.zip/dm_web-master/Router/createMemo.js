//createMemo.js

//chargement des modules
//module perso
var sql = require('./requeteSQL');
var fct = require('./foncts');

//connexion serveur
var express = require('express');
var serv = express();
var router = express.Router();

//POST et Session
const session = require('express-session');
var bodyParser = require('body-parser');
serv.use(bodyParser.json());
serv.use(bodyParser.urlencoded({ extended: false }));
serv.use(session({secret: 'secret',saveUninitialized: true,resave: true}));
var sess; // global session

//Connexion à la bdd
var mysql = require('mysql');
var connection = mysql.createConnection({
  host : 'localhost',
  user : 'etu21600361',
  password : 'etu21600361',
  database : 'etu21600361'
});
connection.connect();

//chargement du repertoire public
serv.use(express.static(__dirname +'/public'));

//initialisation ejs
serv.set('view engine', 'ejs');

//////////////////////////////////////////////////////////////////////////////
//initialisation pseudo
//valeur par défault public
router.use((req,res,next) => {
  sess = req.session;
  if(!sess.pseudo){
    sess.pseudo = "public";
  }
  console.log("session: "+sess.pseudo);
  next();
});

//Enlver un utilisateur du MEMO
router.use('/create/:id/deluser',function(req,res){
  var idMemo = req.params.id;
  var pseudo = "";

  if (sess.pseudo) {
    var pseudo = sess.pseudo;
  }else{
    res.redirect("/Err4/");
  }

    if (typeof req.body.user !== 'undefined') {
      var user = req.body.user;

    var req = sql.reqDelUserCan(idMemo,user);
    connection.query(req, function(err,  result) {
      if (err) throw err;
      console.log(result.affectedRows + " record(s) updated");

      fct.msgSucces(req,res,5);
    });
  }else{
    res.redirect("/Err4");
  }
  setTimeout(() => {
    res.redirect("/");
  }, 50);
});

//Ajouter un utilisateur au MEMO
router.use('create/:id/adduser',function(req,res){
  var idMemo = req.params.id;
  var pseudo = "";
  if (sess.pseudo) {
    var pseudo = sess.pseudo;
  }else{
    res.redirect("/Err4");
  }

  if (typeof req.body.user !== 'undefined') {
    var user = req.body.user;

    var req = sql.reqUserCanMemo(idMemo,user);
    connection.query(req, function(err,  result) {
      if (err) throw err;
      console.log(result.affectedRows + " record(s) updated");

      res.redirect("/Succ3");
    });
  }else{
    res.redirect("/Err4");
  }
  setTimeout(() => {
    res.redirect("/");
  }, 50);
});

//enregitre les modifs du memo
router.use('create/:id/save',function(req,res) {
  var idMemo = req.params.id;
  if (typeof req.body.contenu !== 'undefined') {
    var texte = req.body.contenu;

    var req = sql.reqUpdMemo(idMemo,texte);
    connection.query(req, function(err,  result) {
      if (err) throw err;
      console.log(result.affectedRows + " record(s) updated");

      res.redirect("/Succ2");
    });
  }else{
    res.redirect("/Err4");
  }
  //redirection vers la page d'acceuil
  setTimeout(() => {
    res.redirect("/");
  }, 100);
});

//supprimer un memo
router.use('create/:id/del',function(req,res) {
  var idMemo = req.params.id;
  var pseudo = "";
  if (sess.pseudo) {
    var pseudo = sess.pseudo;

  //verifie qu'on a acces au memos
  var req1 = sql.reqCanUser(idMemo,pseudo);
  connection.query(req1, function(err, rows, fields) {
    if (err) throw err;

    if (rows.length != 0){
      //supprime le memo
      var req2 = sql.reqDelMemo(idMemo);
      connection.query(req2, function(err,  result) {
        if (err) throw err;
        console.log(result.affectedRows + " record(s) updated");

        res.redirect("/Succ2");
      });
    }else{
      res.redirect("/Err5");
    }
  });
  //redirection vers la page d'acceuil
  setTimeout(() => {
    res.redirect("/");
  }, 200);
}else{
  res.redirect("/Err4");
}
});


//verifie si on peut modifier le memo avec det id
router.use('create/:id/',function(req,res,next){
  var idMemo = req.params.id;
  var pseudo = "";
  if (sess.pseudo) {
    var pseudo = sess.pseudo;
  }else{
    res.redirect("/Err4");
  }

  //Memo existe ?
  var req1 = sql.reqIsMemo(idMemo);
  connection.query(req1, function(err, rows, fields) {
    if (err) throw err;
    //si existe pas crée
    if (rows.length == 0){
      //ajout du Memo
      var req2 = sql.reqAddMemo(idMemo,"Nouveau Mémo");
      connection.query(req2, function(err2, rows2, fields2) {
        if (err2) throw err2;
        // res.redirect("/Succ2");//message de succes
      });
      //Autorisation pour le mémo
      var req2bis = sql.reqUserCanMemo(idMemo,pseudo);
      connection.query(req2bis, function(err2bis, rows2bis, fields2bis) {
        if (err2bis) throw err2bis;
        // res.redirect("/Succ3"); //message de succes
      });
      //ajout de l'autorisation public par défault
      if(pseudo != "public"){
        var req2ter = sql.reqUserCanMemo(idMemo,"public");
        connection.query(req2ter, function(err2ter, rows2ter, fields2ter) {
          if (err2ter) throw err2ter;
          // res.redirect("/Succ4"); //message de succes
        });
      }
    }else{
      //si existe
      //veridfe les droits d'accès
      var req3 = sql.reqCanUser(idMemo,pseudo);
      connection.query(req3, function(err3, rows3, fields3) {
        if (err3) throw err3;
        //pas de droits
        if (rows3.length == 0){
          res.redirect("/Err5");
          res.redirect("/");
        }
      });
    }
    setTimeout(() => {
      next('route');
    }, 1000);

  });
  // res.end();
});

//Recupere le texte du Memo et l'affiche
router.use('create/:id/',function(req,res){
  var idMemo = req.params.id;
  var pseudo = "";
  if (sess.pseudo) {
    var pseudo = sess.pseudo;
  }else{
    res.redirect("/Err4");
  }
  //recuperation du memo
  var req1 = sql.reqGetMemo(idMemo);
  connection.query(req1, function(err, rows, fields) {
    if (err) throw err;
    //si pas le bon nombre sort erreur
    if (rows.length != 1){
      res.redirect("/Err6");
    }

    //recuperation des utilisateurs autorisé
    var sharedUser = [];
    var req2 = sql.reqSharedUser(idMemo);
    connection.query(req2, function(err2, rows2, fields2) {
      if (err2) throw err2;

      rows2.forEach(function(elem){
        sharedUser.push(elem.pseudo);
      });
    });

    //Récupération des utilisateurs
    var req3 = sql.reqAllUser();
    connection.query(req3, function(err3, rows3, fields3) {
      if (err3) throw err3;
    //chargement de la page
    setTimeout(() => {
      console.log(rows[0].contenu);
      var erreur = "";
      var succes = "";
      if(sess.erreur){erreur = sess.erreur;}
      if(sess.succes){succes = sess.succes;}
      res.render('pages/create',{
        pseudo : pseudo,
        memo : rows[0],
        sharedUser : sharedUser,
        allUser : rows3,
        erreur:erreur,
        succes:succes
      });
    }, 1000);
  });
  });
});


module.exports = router;
