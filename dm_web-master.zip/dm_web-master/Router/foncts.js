//foncts.js

//chargement des modules
//module perso
var sql = require('./requeteSQL');


//connexion serveur
var express = require('express');
var serv = express();

//bodyparser pour POST
var bodyParser = require('body-parser');
serv.use(bodyParser.urlencoded({ extended: false }));

//Connexion à la bdd
var mysql = require('mysql');
var connection = mysql.createConnection({
  host : 'localhost',
  user : 'etu21600361',
  password : 'etu21600361',
  database : 'etu21600361'
});
connection.connect();

//chargement du repertoire public
serv.use(express.static(__dirname +'/public'));

//initialisation ejs
serv.set('view engine', 'ejs');

//////////////////////////////////////////////////////////////////////////////

// Affiche message d'erreur
var msgErreur = function(choix){
  switch (parseInt(choix)) {
    case 1:
      var msg = "Erreur 1 : pseudo non défini";
      console.log(msg);
      return msg;
      break;
    case 2:
      var msg = "Erreur 2 : mdp non défini";
      console.log(msg);
      return msg;
      break;
    case 3:
      var msg = "Erreur 3 : pseudo déjà utilisé";
      console.log(msg);
      return msg;
      break;
    case 4:
      var msg = "Erreur 4 : élément non défini";
      console.log(msg);
      return msg;
      break;
    case 5:
      var msg = "Erreur 5 : pas autorisé à modifier ce mémo";
      console.log(msg);
      return msg;
      break;
    case 6:
      var msg = "Erreur 6 : erreur inconnu ou de délais dans le router";
      console.log(msg);
      return msg;
      break;
    case 7:
      var msg = "Erreur 7 : Pseudo non existant";
      console.log(msg);
      return msg;
      break;
    case 8:
      var msg = "Erreur 8 : Mauvais mot de passe";
      console.log(msg);
      return msg;
      break;
    default:
    console.log("default : erreur non définie");
  }
}

exports.msgErreur = msgErreur;

//Affiche message de succes
var msgSucces = function(choix){
  switch (parseInt(choix)) {
    case 1:
      var msg = "Succes 1 : compte bien créé défini";
      console.log(msg);
      return msg;
      break;
    case 2:
      var msg = "Succes 2 : Mémo bien créé défini/modifié";
      console.log(msg);
      return msg;
      break;
    case 3:
      var msg = "Succes 3 : Droits User pour Mémo bien ajouté";
      console.log(msg);
      return msg;
      break;
    case 4:
      var msg = "Succes 4 : Mémo accessible au public";
      console.log(msg);
      return msg;
      break;
    case 5:
      var msg = "Succes 5 : Élément bien supprimé";
      console.log(msg);
      return msg;
      break;
    case 6:
      var msg = "Succes 6 : Connexion bien effectuée";
      console.log(msg);
      return msg;
      break;
    case 7:
      var msg = "Succes 7 : Déconnexion bien effectuée";
      console.log(msg);
      return msg;
      break;

    default:
    console.log("default");
  }
}

exports.msgSucces = msgSucces;
