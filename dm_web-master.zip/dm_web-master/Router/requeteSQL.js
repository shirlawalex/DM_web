var mysql = require('mysql');
// r_ stand for raw

//selection des memos visibles
var req1 = function(r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var ret = "SELECT memo.contenu AS contenu, memo.date AS date, memo.ID AS id "+
  "FROM memo "+
  "INNER JOIN contributeur c "+
  "ON memo.ID = c.id_memo "+
  "WHERE c.pseudo = "+pseudo+" "+
  "ORDER BY memo.date DESC";
  return ret;
}
exports.reqMemo = req1;

//utilisateur autorisé du memo
var req2 = function(r_idMemo){
  var idMemo = mysql.escape(r_idMemo);
  var ret ="SELECT c.pseudo AS pseudo "+
  "FROM contributeur c "+
  "INNER JOIN memo "+
  "ON memo.ID = c.id_memo "+
  "WHERE memo.ID ="+idMemo+"";
  return ret;
}
exports.reqSharedUser = req2;

//Ajout du compte
var req3 = function(r_newPseudo,r_newMdp){
  var pseudo = mysql.escape(r_newPseudo);
  var idMemo = mysql.escape(r_newMdp);
  var ret = "INSERT INTO `user` (`ID`, `pseudo`, `mdp`, `Date`)"+
  " VALUES (NULL, "+pseudo+", "+idMemo+", CURRENT_TIME());";
  return ret;
}
exports.reqCreateUser = req3;


//recuperer mot de passe
var req4 = function(r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var ret = "SELECT mdp FROM user WHERE pseudo="+pseudo+" ";
  return ret;
}
exports.reqGetMdp = req4;


//Listes des utilisateurs
var req5 = function(){
  var ret = "SELECT pseudo from user";
  return ret;
}
exports.reqAllUser = req5;


//Suppression utilisateurs
var req6 = function(r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var ret = "DELETE FROM `user` WHERE `user`.`pseudo` = "+pseudo+"";
  return ret;
}
exports.reqDelUser = req6;

//Memo existant
var req7 = function(r_idMemo){
  var idMemo = mysql.escape(r_idMemo);
  var ret = "SELECT ID FROM `memo` WHERE ID = "+idMemo;
  return ret;
}
exports.reqIsMemo = req7;


//Suppression mémos
var req8 = function(r_idMemo){
  var idMemo = mysql.escape(r_idMemo);
  var ret = "DELETE FROM `memo` WHERE `memo`.`ID` = "+idMemo;
  return ret;
}
exports.reqDelMemo = req8;

//Ajout memos
var req9 = function(r_idMemo,r_texte){
  var idMemo = mysql.escape(r_idMemo);
  var texte = mysql.escape(r_texte);
  var ret ="INSERT INTO `memo` (`ID`, `contenu`, `date`) VALUES ("+idMemo+","+
  texte+", CURRENT_TIME()) ";
  return ret;
}
exports.reqAddMemo = req9;

//Modifie memo
var req10 = function(r_idMemo,r_texte){
  var idMemo = mysql.escape(r_idMemo);
  var texte = mysql.escape(r_texte);
  var ret = "UPDATE `memo` SET `contenu` ="+
  texte+" ,`date` = CURRENT_TIME() "+
  "WHERE `memo`.`ID` = "+idMemo;
  return ret;
}
exports.reqUpdMemo = req10;

//Autorise user/memo
var req11 = function(r_idMemo,r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var idMemo = mysql.escape(r_idMemo);
  var ret = "INSERT INTO `contributeur` (`ID`, `id_memo`, `pseudo`) "+
  "VALUES (NULL, "+idMemo+", "+pseudo+");";
  return ret;
}
exports.reqUserCanMemo = req11;

//Supprime user/memo
var req12 = function(r_idMemo,r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var idMemo = mysql.escape(r_idMemo);
  var ret = "DELETE FROM `contributeur`"+
  " WHERE `contributeur`.`id_memo` = "+idMemo+
  " AND `contributeur`.`pseudo` = "+pseudo+"";
  return ret;
}
exports.reqDelUserCan = req12;

//Est ce que l'user à acces au memo
var req13 = function(r_idMemo,r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var idMemo = mysql.escape(r_idMemo);
  var ret = "SELECT `contributeur`.`ID` FROM `contributeur`"+
  " WHERE `contributeur`.`id_memo` = "+idMemo+
  " AND `contributeur`.`pseudo` = "+pseudo+"";
  return ret;
}
exports.reqCanUser = req13;

//recuperer le contenu du memo
var req14 = function(r_idMemo){
  var idMemo = mysql.escape(r_idMemo);
  var ret = "SELECT memo.contenu AS contenu, memo.date AS date, memo.ID AS id"+
  " FROM `memo` WHERE `ID`="+idMemo;
  return ret;
}
exports.reqGetMemo = req14;

//l'utilisateur existe
var req15 = function(r_pseudo){
  var pseudo = mysql.escape(r_pseudo);
  var ret = "SELECT pseudo"+
  " FROM `user` WHERE `pseudo`="+pseudo+"";
  return ret;
}
exports.reqIsUser = req15;
