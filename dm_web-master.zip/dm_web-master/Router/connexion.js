//connexion.js

//chargement des modules
//module perso
var sql = require('./requeteSQL');
var fct = require('./foncts');

//connexion serveur
var express = require('express');
var serv = express();
var router = express.Router();

//POST et Session
const session = require('express-session');
var bodyParser = require('body-parser');
serv.use(bodyParser.json());
serv.use(bodyParser.urlencoded({ extended: false }));
serv.use(session({secret: 'secret',saveUninitialized: true,resave: true}));
var sess; // global session

//Connexion à la bdd
var mysql = require('mysql');
var connection = mysql.createConnection({
  host : 'localhost',
  user : 'etu21600361',
  password : 'etu21600361',
  database : 'etu21600361'
});
connection.connect();

//Hashfunction
var md5 = require('md5');


//chargement du repertoire public
serv.use(express.static(__dirname +'/public'));

//initialisation ejs
serv.set('view engine', 'ejs');

//////////////////////////////////////////////////////////////////////////////

//initialisation pseudo
//valeur par défault public
router.use((req,res,next) => {
  sess = req.session;
  if(!sess.pseudo){
    sess.pseudo = "public";
  }
  console.log("session: "+sess.pseudo);
  next();
});


//deconexion par post
router.post('/unlogin',(req,res) => {
  sess.pseudo = "public";
  console.log("deconnexion.");
  res.redirect("/Succ7/accueil");
});

//connexion par post
router.post('/login',(req,res) => {
  if(typeof req.body.pseudo !== 'undefined'){
    if(typeof req.body.mdp !== 'undefined'){

      var user = req.body.pseudo;
      var mdp = req.body.mdp;
      console.log("connexion en cours...");

      var req1 = sql.reqIsUser(user);
      connection.query(req1, function(err, rows, fields) {
        if (err) throw err;

        if(rows.length != 0){

          var req2 = sql.reqGetMdp(user);
          connection.query(req2, function(err2, rows2, fields2) {
            if (err2) throw err2;
            //HASH fonction
            var hashmdp = md5(mdp);
            var bddmdp = rows2[0].mdp;
            console.log(bddmdp);
            console.log(hashmdp+" : "+hashmdp.length);
            //calcule le mdp et compare rows2[0].mdp
            if(bddmdp == hashmdp){
              sess.pseudo = user;
              res.redirect("/Succ6/accueil");
            }else{
              res.redirect("/Err8/accueil");
            }
          });

        }else{
          res.redirect("/Err7/accueil");
        }
      });
    }else{
      res.redirect("/Err2/accueil");
    }
  }else{
    res.redirect("/Err1/accueil");
  }
});

//inscription
router.get('/register',(req,res) =>{
  var erreur = "";
  var succes = "";
  if(sess.erreur){erreur = sess.erreur;}
  if(sess.succes){succes = sess.succes;}
  res.render('pages/register',{pseudo:sess.pseudo,erreur:erreur,succes:succes});
});

//creation
router.post('/register/create',(req,res) =>{
  if(typeof req.body.pseudo !== 'undefined'){
    if(typeof req.body.mdp !== 'undefined'){

      var user = req.body.pseudo;
      var mdp = req.body.mdp;
      console.log("connexion en cours...");

      var req1 = sql.reqIsUser(user);
      connection.query(req1, function(err, rows, fields) {
        if (err) throw err;

        if(rows.length == 0){

          var hashmdp = md5(mdp);

          var req2 = sql.reqCreateUser(user,hashmdp);
          connection.query(req2, function(err2, result) {
            if (err2) throw err2;
            console.log(result.affectedRows + " record(s) updated");
            sess.pseudo=user;
            res.redirect("/Succ1/accueil");
          });
        }else{
          res.redirect("/Err3/register");
        }
      });
    }else{
      res.redirect("/Err2/register");
    }
  }else{
    res.redirect("/Err1/register");
  }
});

//supprime compte
router.post('/register/del',(req,res)=>{
  console.log("delete account");
  console.log(mdp);
  if(typeof req.body.mdp !== 'undefined'){

    var user = sess.pseudo;
    var mdp = req.body.mdp;


    var req2 = sql.reqGetMdp(user);
    connection.query(req2, function(err2, rows2, fields2) {
      if (err2) throw err2;
      //HASH fonction
      var hashmdp = md5(mdp);
      var bddmdp = rows2[0].mdp;
      console.log(bddmdp);
      console.log(hashmdp+" : "+hashmdp.length);
      //calcule le mdp et compare rows2[0].mdp
      if(bddmdp == hashmdp){
        sess.pseudo = "public";

        var req = sql.reqDelUser(user);
        connection.query(req, function(err,  result) {
          if (err) throw err;
          console.log(result.affectedRows + " record(s) updated");

          res.redirect("/Succ2/accueil");
        });

      }else{
        res.redirect("/Err8/register");
      }
    });
  }else{
    res.redirect("/Err2/register");
  }
});

module.exports = router;
