//accueil.js

//chargement des modules
//module perso
var sql = require('./requeteSQL');
var fct = require('./foncts');

//connexion serveur
var express = require('express');
var serv = express();
var router = express.Router();

//POST et Session
const session = require('express-session');
var bodyParser = require('body-parser');
serv.use(bodyParser.json());
serv.use(bodyParser.urlencoded({ extended: false }));
serv.use(session({secret: 'secret',saveUninitialized: true,resave: true}));
var sess; // global session

//Connexion à la bdd
var mysql = require('mysql');
var connection = mysql.createConnection({
  host : 'localhost',
  user : 'etu21600361',
  password : 'etu21600361',
  database : 'etu21600361'
});
connection.connect();

//chargement du repertoire public
serv.use(express.static(__dirname +'/public'));

//initialisation ejs
serv.set('view engine', 'ejs');

//////////////////////////////////////////////////////////////////////////////
//initialisation pseudo
//valeur par défault public
router.use((req,res,next) => {
  sess = req.session;
  if(!sess.pseudo){
    sess.pseudo = "public";
  }
  console.log("session: "+sess.pseudo);
  next();
});


serv.use("/",(req,res)=>{res.redirect("/accueil")});
// serv.get("/",(req,res)=>{res.redirect("/accueil")});
// serv.post("/",(req,res)=>{res.redirect("/accueil")});


//GENERER L'ACCUEIL ET LES MEMOS
router.use('/accueil',function(req,res){
  var pseudo = sess.pseudo;
  var req1 = sql.reqMemo(pseudo);

  //Recupération des memos dans la base de données
  connection.query(req1, function(err, rows, fields) {
    if (err) throw err;

    var alluser = [];
    rows.forEach(function(rows){

      memoId = rows.id;
      var userof = [];
      var req2 = sql.reqSharedUser(memoId);

      //Récupération des utilisateurs
      connection.query(req2, function(err2, rows2, fields2) {
        if (err2) throw err2;

        rows2.forEach(function(elem){
          userof.push(elem.pseudo);
        });
      });
      alluser.push(userof);
    });
    setTimeout(() => {
      var erreur = "";
      var succes = "";
      if(sess.erreur){erreur = sess.erreur;}
      if(sess.succes){succes = sess.succes;}
      res.render('pages/index',{
        pseudo : pseudo,
        memos : rows,
        user : alluser,
        succes:succes,
        erreur:erreur
      });
    }, 1000);
  });
});


module.exports = router;
