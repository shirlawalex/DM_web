Devoir maison de Alex Shirlaw
21600361

Creation de host / user / password / database
Tous les privileges

CREATE USER 'etu21600361'@'%' IDENTIFIED WITH mysql_native_password AS '***';GRANT ALL PRIVILEGES ON *.* TO 'etu21600361'@'%' REQUIRE NONE WITH GRANT OPTION MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0 MAX_USER_CONNECTIONS 0;CREATE DATABASE IF NOT EXISTS `etu21600361`;GRANT ALL PRIVILEGES ON `etu21600361`.* TO 'etu21600361'@'%';GRANT ALL PRIVILEGES ON `etu21600361\_%`.* TO 'etu21600361'@'%';

******

Voila les parametres de connexion:
  host : 'localhost',
  user : 'etu21600361',
  password : 'etu21600361',
  database : 'etu21600361'

Une base de donnée de base est installé dans la database etu21600361 se trouvant sur lampe.

Sinon le fichier memo.sql permet de l'importer
