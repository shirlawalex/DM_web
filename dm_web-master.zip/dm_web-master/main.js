//server.js

//chargement des modules
//module perso
var fct = require('./Router/foncts');
var sql = require('./Router/requeteSQL');
var createMemo = require('./Router/createMemo');
var connexion = require('./Router/connexion');
var accueil = require('./Router/accueil');

//connexion serveur
var express = require('express');
var serv = express();

//POST et Session
const session = require('express-session');
var bodyParser = require('body-parser');
serv.use(bodyParser.json());
serv.use(bodyParser.urlencoded({ extended: false }));
serv.use(session({secret: 'secret',saveUninitialized: true,resave: true}));


//chargement du repertoire public
serv.use(express.static(__dirname +'/public'));

//initialisation ejs
serv.set('view engine', 'ejs');

//////////////////////////////////////////////////////////////////////////////



var sess; // global session
serv.use((req,res,next) => {
  sess = req.session;
  if(!sess.pseudo){
    sess.pseudo = "public";
  }
  //console.log("session: "+sess.pseudo);
  next();
});

//Message d'erreur ou echec
serv.use('/Err:nb',(req,res,next)=>{
  sess.erreur = fct.msgErreur(req.params.nb);
  console.log(sess.erreur);
  next();
},accueil,connexion,createMemo);

//Message de réussite d'opération dans la base de donnée
serv.use('/Succ:nb',(req,res,next)=>{
  console.log(req.params.nb);
  sess.succes = fct.msgSucces(req.params.nb);
  console.log(sess.succes);
  next();
},accueil,connexion,createMemo);



//Page acceuil, connexion et creation de
serv.use("/",accueil,connexion,createMemo);

serv.use("/",(req,res)=>{res.redirect("/accueil")});


//Autres
serv.use(function(req,res,next){
  res.send("page non défini ");
  res.status(404).end("error");
});

//port 8080
serv.listen(8080);
