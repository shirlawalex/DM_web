-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 29, 2020 at 07:47 AM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `etu21600361`
--

-- --------------------------------------------------------

--
-- Table structure for table `contributeur`
--

CREATE TABLE `contributeur` (
  `ID` int(10) UNSIGNED NOT NULL,
  `id_memo` int(10) UNSIGNED NOT NULL,
  `pseudo` varchar(12) NOT NULL DEFAULT 'public'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contributeur`
--

INSERT INTO `contributeur` (`ID`, `id_memo`, `pseudo`) VALUES
(10, 4, 'alex'),
(18, 2, 'Cassou'),
(19, 2, 'alex'),
(23, 657449, 'Cassou'),
(30, 897648, 'Cassou'),
(32, 897648, 'alex'),
(39, 4, 'public'),
(40, 2, 'public'),
(47, 0, 'public');

-- --------------------------------------------------------

--
-- Table structure for table `memo`
--

CREATE TABLE `memo` (
  `ID` int(10) UNSIGNED NOT NULL,
  `contenu` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `memo`
--

INSERT INTO `memo` (`ID`, `contenu`, `date`) VALUES
(0, 'Bonjour et bienvenue sur le site\r\n\r\nVoici un exemple de Mémo.\r\n\r\nVous pouvez en créer et partager avec vos amis.\r\nPour cela il suffit de créer un compte.\r\nÀ vous de jouer\r\n', '2099-12-31'),
(2, 'Rendre le sujet avant 20h', '2020-03-27'),
(4, 'Lorem ipsum dolor sit amet,  adipiscing elit. Quisque accumsan ligula in arcu fermentum accumsan. Pellentesque ut ligula egestas elit consectetur laoreet quis eu. Morbi placerat velit in suscipit laoreet. Aliquam tristique dui at neque porta, ut vehicula nunc mattis. Pellentesque condimentum pulvinar elit, sit amet interdum dui facilisis at. Phasellus tellus erat, sodales et interdum eu, pharetra in quam. In sollicitudin gravida erat eget ornare. Fusce a sodales risus. Morbi convallis dignissim feugiat. In hac habitasse platea dictumst. Mauris eu vulputate nulla, viverra aliquet augue. Praesent at arcu elit. Nam sed velit in magna egestas semper eget at felis. Fusce pretium, quam quis malesuada efficitur, ex arcu congue lectus, nec congue lacus enim eu metus. Sed a gravida dui.\r\n\r\n', '2020-03-27'),
(657449, 'Faire mes courses', '2020-03-27'),
(897648, 'Se laver les mains', '2020-03-27');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) UNSIGNED NOT NULL,
  `pseudo` varchar(12) NOT NULL,
  `mdp` char(32) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `pseudo`, `mdp`, `Date`) VALUES
(1, 'public', 'd41d8cd98f00b204e9800998ecf8427e', '2020-03-29'),
(2, 'alex', 'aa36dc6e81e2ac7ad03e12fedcb6a2c0', '2020-03-26'),
(3, 'Cassou', 'aa36dc6e81e2ac7ad03e12fedcb6a2c0', '2020-03-26'),
(7, 'Pseudo', 'aa36dc6e81e2ac7ad03e12fedcb6a2c0', '2020-03-29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contributeur`
--
ALTER TABLE `contributeur`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `id_memo` (`id_memo`),
  ADD KEY `pseudo` (`pseudo`);

--
-- Indexes for table `memo`
--
ALTER TABLE `memo`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `pseudo_2` (`pseudo`),
  ADD KEY `ID_2` (`ID`),
  ADD KEY `pseudo` (`pseudo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contributeur`
--
ALTER TABLE `contributeur`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `memo`
--
ALTER TABLE `memo`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=918619;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `contributeur`
--
ALTER TABLE `contributeur`
  ADD CONSTRAINT `contributeur_ibfk_1` FOREIGN KEY (`id_memo`) REFERENCES `memo` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contributeur_ibfk_3` FOREIGN KEY (`pseudo`) REFERENCES `user` (`pseudo`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
